#Where statements

Select * from parks_and_recreation.employee_demographics
where first_name = 'Leslie';

#Comparison operators

Select * 
from parks_and_recreation.employee_salary
where salary >= 50000;

Select *
from parks_and_recreation.employee_demographics
where gender = 'Male';

Select * 
from parks_and_recreation.employee_demographics
Where first_name = 'Tom';

#logical operators AND OR NOT

Select *
from parks_and_recreation.employee_demographics
where birth_date = '1980-11-11' 
and gender = 'Male';

Select * 
from parks_and_recreation.employee_salary
where dept_id > 2 
or not salary <= 50000;

Select *
from parks_and_recreation.employee_demographics
where (age > 30 and age <= 60 and age != 40) and gender = 'Male' or employee_id > 10;

#like statements 
# % and _ statements

#First statment extracts all names starting with A, must be longer than 3 characters
Select *
from parks_and_recreation.employee_demographics
where first_name
like 'a__%';

# Second statement extracts the string 'er'
Select *
from parks_and_recreation.employee_demographics
where last_name 
like '%er%';

#third statement extract on birthdates for March
Select *
from parks_and_recreation.employee_demographics
where birth_date
like '_____03___';

#fourth statement extracts a first name greater than 4 or more characters but starts with an A
Select * 
from parks_and_recreation.employee_salary
where first_name 
like 'A___%';

#Thank you for taking the time to look at my demonstrated SQL queries