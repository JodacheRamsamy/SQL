-- Having vs Where

-- Query extracts data from either female or male, and extracts data where the average age is above 35
Select gender, avg(age)
from parks_and_recreation.employee_demographics
group by gender
having avg(age) > 35;

-- Query extracts data from either female or male, and extracts data where the average age is above 40 
Select gender, avg(age)
from parks_and_recreation.employee_demographics 
group by gender
having avg(age) > 40;

-- Query extracts which occupation receives the biggest salary
Select occupation, avg(salary)
from parks_and_recreation.employee_salary
group by occupation
having avg(salary) > 0;

-- Query extracts how much a manager receives as a salary
Select occupation, avg(salary)
from parks_and_recreation.employee_salary
where occupation like '%manager%'
group by occupation;

-- Query extracts which manager receives the bigger salary based on the query above which found out how much managers
Select occupation, avg(salary)
from parks_and_recreation.employee_salary
where occupation like '%manager%'
group by occupation
having avg(salary) > 75000; 