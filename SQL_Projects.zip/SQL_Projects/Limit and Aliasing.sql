-- Limit and Aliasing

-- Extracts the 3 oldest employees
Select * 
from parks_and_recreation.employee_demographics
order by age desc
limit 3;

-- Extracts the 2nd oldest employee
Select *
from parks_and_recreation.employee_demographics
order by age desc
limit 1, 1 ;

-- Extracts the 3 newbies
Select *
from parks_and_recreation.employee_demographics
order by age asc
limit 3;

-- Extracts the 3rd youngest employee
Select * 
from parks_and_recreation.employee_demographics
order by age asc
limit 2, 1;

-- Aliasing 

-- Extracts the average age for the gender above age 40
Select gender, avg(age)
from parks_and_recreation.employee_demographics
group by gender
having avg(age) > 40 ;

-- Same as the above but not the column change with 2 variants below
Select gender, avg(age) AS a_a
from parks_and_recreation.employee_demographics
group by gender
having a_a > 40;

Select gender, avg(age) avg_age
from parks_and_recreation.employee_demographics
group by gender
having avg_age > 40;

