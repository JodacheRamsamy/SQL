-- Group By, Min, Max, Count, Avg
 
-- Query extracts the genders 
Select gender
from parks_and_recreation.employee_demographics
group by gender;

-- Query extracts the average age for the two genders
Select gender, avg(age)
from parks_and_recreation.employee_demographics
group by gender;

-- Query extracts the average, maximum, minimum and count for the age of the two genders
Select gender, avg(age), max(age), min(age), count(age)
from parks_and_recreation.employee_demographics
group by gender;

-- Order by

-- Query will extract data in ascending order for the relevant column
Select * 
from parks_and_recreation.employee_demographics
order by gender;

Select *
from parks_and_recreation.employee_demographics
order by gender asc;

-- Query will extract data in order of descending

Select * 
from parks_and_recreation.employee_salary
order by first_name desc;

Select *
from parks_and_recreation.employee_salary
order by last_name desc;

-- Query will extract data in descending age featuring females first

Select *
from parks_and_recreation.employee_demographics
order by gender, age desc;

-- Query will extract data in ascending age but priortize males

Select *
from parks_and_recreation.employee_demographics
order by gender desc, age asc;

