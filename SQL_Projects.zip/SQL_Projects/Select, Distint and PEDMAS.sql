#Select and Distinct statments, and PEDMAS

#1
Select * 
from parks_and_recreation.employee_demographics;

#2
Select first_name, gender
from parks_and_recreation.employee_demographics;

#3
Select first_name,
age,
birth_date 
from parks_and_recreation.employee_demographics;

#4
Select distinct gender 
from parks_and_recreation.employee_demographics;

#5
Select distinct first_name, gender
from parks_and_recreation.employee_demographics;

#6
Select first_name, 
age, 
age + 20 
from parks_and_recreation.employee_demographics;

#7
Select first_name, 
age, 
(age*2) + 10/5 
from parks_and_recreation.employee_demographics;

#8 
Select first_name, 
age, 
age*2 + (10/2)*5
from parks_and_recreation.employee_demographics;

#Thank you for taking the time to look at my demonstrated SQL queries