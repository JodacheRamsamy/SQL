Select * 
from parks_and_recreation.employee_demographics;

Select * 
from parks_and_recreation.employee_salary;

-- Extracts all information from both tables that are identical based on the employee ID
Select * 
from parks_and_recreation.employee_demographics AS em
inner join parks_and_recreation.employee_salary AS es	
	on em.employee_id = es.employee_id;
    
-- Extracts employee id, age, birth date, first name, and last name from both tables 
Select em.employee_id, em.age, em.birth_date, em.first_name, em.last_name
from parks_and_recreation.employee_demographics AS em
inner join parks_and_recreation.employee_salary AS es	
	on em.employee_id = es.employee_id;

-- Extracts age and birthdates, where the employee ID is the same
Select es.employee_id, age, birth_date
from parks_and_recreation.employee_demographics AS em
inner join parks_and_recreation.employee_salary AS es	
	on em.employee_id = es.employee_id;
 
 -- Outer Joins
 Select em.employee_id, em.first_name, age, birth_date
 from parks_and_recreation.employee_demographics AS em
 right join parks_and_recreation.employee_salary AS es
	on em.employee_id = es.employee_id;
    
 Select em.employee_id, em.first_name, age, birth_date
 from parks_and_recreation.employee_demographics AS em
 left join parks_and_recreation.employee_salary AS es
	on em.employee_id = es.employee_id;

-- Extracts all data from the right table that are the same on the left, anything not the same from the right, will be marked as null
Select *
from parks_and_recreation.employee_demographics AS em
right join parks_and_recreation.employee_salary As es	
		on em.employee_id = es.employee_id;
        
-- Join 3 tables together, 1 table with no common variables with the other 2

Select *
from parks_and_recreation.employee_demographics as em
inner join parks_and_recreation.employee_salary as es	
	on em.employee_id = es.employee_id
inner join parks_and_recreation.parks_departments as pd	
	on pd.department_id = es.dept_id;
    
    

	
	
	

    